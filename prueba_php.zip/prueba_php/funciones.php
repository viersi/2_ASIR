<?php

function cargarTareas() {
    if (!file_exists('tareas.json')) {
        return [];
    }
    $json = file_get_contents('tareas.json');
    return json_decode($json, true) ?? [];
}

function guardarTareas($tareas) {
    file_put_contents('tareas.json', json_encode($tareas, JSON_PRETTY_PRINT));
}

function agregarTarea($titulo) {
    $tareas = cargarTareas();
    $tareas[] = [
        'titulo' => htmlspecialchars($titulo),
        'completada' => false
    ];
    guardarTareas($tareas);
}

function completarTarea($id) {
    $tareas = cargarTareas();
    if (isset($tareas[$id])) {
        $tareas[$id]['completada'] = true;
    }
    guardarTareas($tareas);
}

function eliminarTarea($id) {
    $tareas = cargarTareas();
    if (isset($tareas[$id])) {
        unset($tareas[$id]);
    }
    guardarTareas(array_values($tareas));
}
