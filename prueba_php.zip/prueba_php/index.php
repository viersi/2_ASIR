<?php
require_once 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nueva_tarea'])) {
        agregarTarea($_POST['nueva_tarea']);
    }
}

if (isset($_GET['completar'])) {
    completarTarea($_GET['completar']);
}

if (isset($_GET['eliminar'])) {
    eliminarTarea($_GET['eliminar']);
}

$tareas = cargarTareas();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Prueba PHP Segundo de Asir</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>Check-List para instalar PHP en LINUX</h1>

    <form method="post">
        <input type="text" name="nueva_tarea" placeholder="Escribe una tarea..." required>
        <button type="submit">Añadir</button>
    </form>

    <h2>Lista de tareas:</h2>

    <ul>
        <?php foreach ($tareas as $id => $tarea): ?>
            <li class="<?php echo $tarea['completada'] ? 'completa' : ''; ?>">
                <?php echo $tarea['titulo']; ?>

                <?php if (!$tarea['completada']): ?>
                    <a href="?completar=<?php echo $id; ?>">✔ Completar</a>
                <?php endif; ?>

                <a href="?eliminar=<?php echo $id; ?>">🗑 Eliminar</a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

</body>
</html>
